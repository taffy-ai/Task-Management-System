from database.__init__ import database
from bson.objectid import ObjectId
from flask import jsonify
import app_config as config

db = database.database

def create_task(task_data, user_info):
    try:
        assigned_user_id = ObjectId(task_data["assignedToUid"])
        assigned_user = db[config.CONST_USER_COLLECTION].find_one(
            {'_id': assigned_user_id}
        )

        if not assigned_user:
            return jsonify({'error': 'Assigned user not found!'}), 400

        task = {
            "createdByUid": user_info["id"],
            "createdByName": user_info["email"],
            "assignedToUid": str(assigned_user["_id"]),
            "assignedToName": assigned_user["name"],
            "description": task_data["description"],
            "done": False
        }
        created_task = db["tasks"].insert_one(task)
        return jsonify({'id': str(created_task.inserted_id)})

    except Exception as e:
        print(f"Error creating task: {e}")
        return jsonify({'error': 'Error creating task'}), 500


def fetch_created_tasks(user_id):
    try:
        tasks = list(db["tasks"].find({"createdByUid": user_id}))
        formatted_tasks = _format_tasks(tasks)
        return jsonify({'tasks': formatted_tasks})

    except Exception as e:
        print(f"Error fetching tasks: {e}")
        return jsonify({'error': 'Error fetching tasks'}), 500


def fetch_assigned_tasks(user_id):
    try:
        tasks = list(db["tasks"].find({"assignedToUid": user_id}))
        formatted_tasks = _format_tasks(tasks)
        return jsonify({'tasks': formatted_tasks})

    except Exception as e:
        print(f"Error fetching assigned tasks: {e}")
        return jsonify({'error': 'Error fetching tasks'}), 500


def update_task(task_id, user_info, update_data):
    try:
        task = db["tasks"].find_one({"_id": ObjectId(task_id)})
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        if task['assignedToUid'] != user_info['id']:
            return jsonify({'error': 'Users can only change status when task is assigned to them'}), 403

        if 'done' not in update_data:
            return jsonify({'error': 'Status done not found in the request'}), 400

        db["tasks"].update_one({"_id": task["_id"]}, {"$set": {"done": update_data["done"]}})
        return jsonify({'taskUid': task_id})

    except Exception as e:
        print(f"Error updating task: {e}")
        return jsonify({'error': 'Error updating task'}), 500


def delete_task(task_id, user_info):
    try:
        task = db["tasks"].find_one({"_id": ObjectId(task_id)})
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        if task['createdByUid'] != user_info['id']:
            return jsonify({'error': 'Users can only delete when task is created by them'}), 403

        result = db["tasks"].delete_one({"_id": task["_id"]})
        return jsonify({'tasksAffected': result.deleted_count}), 200

    except Exception as e:
        print(f"Error deleting task: {e}")
        return jsonify({'error': 'Error deleting task'}), 500


def _format_tasks(tasks):
    return [
        {
            "assignedToName": task["assignedToName"],
            "assignedToUid": task["assignedToUid"],
            "createdByName": task["createdByName"],
            "createdByUid": task["createdByUid"],
            "description": task["description"],
            "done": task["done"],
            "taskUid": str(task["_id"])
        }
        for task in tasks
    ]
