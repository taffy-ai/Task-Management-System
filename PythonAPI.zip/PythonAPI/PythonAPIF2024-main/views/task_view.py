from flask import Blueprint, request, jsonify
from helpers.token_validation import validate_token
import controllers.task_controller as task_controller

task_view = Blueprint('task_view', __name__)

# VALIDATE TOKEN
def get_valid_token():
    token = validate_token()
    if token == 400:
        return jsonify({"error": 'Token is missing in the request, please try again'}), 401, None
    if token == 401:
        return jsonify({"error": 'Invalid authentication token, please login again'}), 403, None
    return None, None, token

# CREATE TASK : POST /tasks/
@task_view.route('/tasks/', methods=['POST'])
def create_task():
    try:
        error_response, status, token = get_valid_token()
        if error_response:
            return error_response, status

        task_data = request.json
        if 'description' not in task_data or 'assignedToUid' not in task_data:
            return jsonify({'error': 'Error validating form'}), 400

        return task_controller.create_task(task_data, token)
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Error creating task'}), 500

# GET TASKS CREATED BY USER : GET /tasks/createdby/
@task_view.route('/tasks/createdby/', methods=['GET'])
def get_created_tasks():
    try:
        error_response, status, token = get_valid_token()
        if error_response:
            return error_response, status

        return task_controller.fetch_created_tasks(token['id'])
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Error fetching tasks'}), 500


# GET TASKS ASSIGNED TO USER : GET /tasks/assignedto/
@task_view.route('/tasks/assignedto/', methods=['GET'])
def get_assigned_tasks():
    try:
        error_response, status, token = get_valid_token()
        if error_response:
            return error_response, status


        return task_controller.fetch_assigned_tasks(token['id'])
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Error fetching tasks'}), 500

# UPDATE TASK : PATCH /tasks/<taskUid>
@task_view.route('/tasks/<taskUid>', methods=['PATCH'])
def update_task(taskUid):
    try:
        error_response, status, token = get_valid_token()
        if error_response:
            return error_response, status

        update_data = request.json
        if not update_data:
            return jsonify({'error': 'No data provided'}), 400

        return task_controller.update_task(taskUid, token, update_data)
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Error updating task'}), 500

# DELETE TASK : DELETE /tasks/<taskUid>
@task_view.route('/tasks/<taskUid>', methods=['DELETE'])
def delete_task(taskUid):
    try:
        error_response, status, token = get_valid_token()
        if error_response:
            return error_response, status

        return task_controller.delete_task(taskUid, token)
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'Error deleting task'}), 500
