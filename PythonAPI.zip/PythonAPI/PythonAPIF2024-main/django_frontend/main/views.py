import requests
from django.shortcuts import render, redirect
from django.contrib import messages

# Create your views here.

def signup(request):
    if request.method == 'POST':
        data = {
            "email" : request.POST['email'],
            "name" : request.POST['name'],
            "password" : request.POST['password']
        }
        response = requests.post("http://127.0.0.1:5000/v0/users/signup", json=data)
        if response.status_code == 200:
            messages.success(request, "Signup Successful !")
            return redirect('login')
        else:
            messages.error(request, "Error: " + response.json().get("error", "Unknown error"))
    return render(request, 'main/signup.html')



def login(request):
    if request.method == 'POST':
       data = {
            "email": request.POST['email'],
            "password": request.POST['password']
        }
       response = requests.post("http://127.0.0.1:5000/v0/users/login", json=data)
       if response.status_code == 200:
           request.session['token'] = response.json()['token']
           return redirect('task_list')
       else:
           messages.error(request, "Error: " + response.json().get("error", "Login error"))
    return render(request, 'main/login.html')



def create_task(request):
    # SESSION TOKEN
    token = request.session.get('token')
    if not token:
        messages.error(request, "You must be logged in to create a task")
        return redirect('login')

    headers = {'x-access-token': token}
    
    # FETCH LIST
    response = requests.get("http://127.0.0.1:5000/v0/users/all", headers=headers)
    if response.status_code == 200:
        users = response.json().get("users", [])
    else:
        users = []
        messages.error(request, "Failed to load users for assignment")

    if request.method == 'POST':
        data = {
            "description": request.POST.get("description"),
            "assignedToUid": request.POST.get("assignedToUid")
        }

        # REQUEST TO FLASK API (AUTH)
        response = requests.post("http://127.0.0.1:5000/tasks/", headers=headers, json=data)
        if response.status_code == 200:
            messages.success(request, "Task created successfully!")
            return redirect('task_list')
        else:
            error_message = response.json().get("error", "Failed to create task")
            messages.error(request, f"Error: {error_message}")
    return render(request, 'main/create_task.html', {'users': users})



def task_list(request):
    token = request.session.get('token')
    if not token:
        return redirect('login')
    
    headers = {'x-access-token': token}
    response = requests.get("http://127.0.0.1:5000/tasks/createdby/", headers=headers)
    
    tasks = response.json().get('tasks', []) if response.status_code == 200 else [] 

    return render(request, 'main/task_list.html', {'tasks': tasks})


def assigned_tasks(request):
    token = request.session.get('token')
    if not token:
        return redirect('login')
    
    headers = {'x-access-token': token}
    response = requests.get("http://127.0.0.1:5000/tasks/assignedto/", headers=headers)

    tasks = response.json().get('tasks', []) if response.status_code == 200 else []

    return render(request, 'main/assigned_tasks.html', {'tasks': tasks})
    

def update_task(request, task_uid):
    if request.method == 'POST':
        token = request.session.get('token')
        if not token:
            return redirect('login')
        
        headers = {'x-access-token': token}
        data = {"done": request.POST.get("done", "false").lower() == "true"} 
        response = requests.patch(f"http://127.0.0.1:5000/tasks/{task_uid}", headers=headers, json=data)

        if response.status_code == 200:
            messages.success(request, "Task updated successfully !")
        else:
            messages.error(request, "Error updating task")
        
        return redirect('task_list')
    return render(request, 'main/update_task.html')


def delete_task(request, task_uid):
    token = request.session.get('token')
    if not token:
        messages.error(request, "You must be logged in to delete a task")
        return redirect('login')
    
    headers = {'x-access-token': token}
    response = requests.delete(f"http://127.0.0.1:5000/tasks/{task_uid}", headers=headers)

    if response.status_code == 200:
        messages.success(request, "Task deleted successfully!")
    else:
        messages.error(request, "Error deleting task")
    
    return redirect('task_list')
    

def logout(request):
    request.session.flush()
    messages.success(request, "You have been logged out")
    return redirect('login')

