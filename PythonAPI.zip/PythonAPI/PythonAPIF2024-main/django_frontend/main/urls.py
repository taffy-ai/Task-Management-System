from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('tasks/create/', views.create_task, name='create_task'),
    path('tasks/', views.task_list, name='task_list'),
    path('tasks/assigned/', views.assigned_tasks, name='assigned_tasks'),
    path('tasks/<str:task_uid>/update/', views.update_task, name='update_task'),
    path('tasks/<str:task_uid>/delete/', views.delete_task, name='delete_task'),
    path('logout/', views.logout, name='logout')
]